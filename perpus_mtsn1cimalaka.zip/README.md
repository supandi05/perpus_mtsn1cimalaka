# perpus_mtsn1cimalaka
 
